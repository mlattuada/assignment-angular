angular.module('Directives', []);

// ADD EVERY DIRECTIVE YOU CREATE TO THIS FILE. EX:

require('./directives/someDirective.js');
