angular.module('Controllers')
    .controller('HomeController', ['$scope', 'Helper',function ($scope, Helper) {

    }]);
