angular.module('Controllers')
    .controller('ContactController', ['$scope', function ($scope, $routeParams) {


    	function init() {
    		$scope.contacts = [];
    		$scope.contact = {};
    		$scope.upsertMessage = '';

    		if($routeParams.id) { loadContactData($routeParams.id); }

    		$scope.upsert = function(){
    			if(validateContact($scope.contact)) {
					CRUDContactController.upsert(
	    				$scope.contact.FirstName,
	    				$scope.contact.LastName,
	    				$scope.contact.Username,
	    				$scope.contact.Password,
	    				function(result) {
	    					if(result) {
	    						$scope.upsertMessage = 'You have added a new contact: ' + result;
	    						$scope.contact.Id = result;
	    						$scope.contacts.push($scope.contact);
	    					} else {
	    						$scope.upsertMessage = 'Something went wrong at the server...';
	    					}
	    				}
					);
    			} else {
    				$scope.upsertMessage = 'Invalid fom data...'; 
    			}
    		};

    		var validateContact = function(contact) {
    			return contact.Password === contact.RepeatedPassword;
    		};

    		var loadContactData = function(id) {
    			CRUDContactController.getContactById(id, function(result) {
    				$scope.contact.FirstName = result.FirstName;
    				$scope.contact.LastName = result.LastName;
    				$scope.contact.Username = result.Username;
    				$scope.contact.Password = result.Password;
    			});
    		};

    		CRUDContactController.listContacts(function(result) {
    			$scope.contacts = result;
    		});
    	}

    	init();

    }]);