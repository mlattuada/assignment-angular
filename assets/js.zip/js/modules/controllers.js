angular.module('Controllers', []);

// ADD EVERY CONTROLLER YOU CREATE TO THIS FILE. EX:
require('./controllers/homeController.js');
require('./controllers/contactController.js');
