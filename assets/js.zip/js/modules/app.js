(function() {

    ////////////////////////////////////////////////////////////
    // App
    ////////////////////////////////////////////////////////////

    var App = angular.module('YourApp', ['ngRoute', 'pasvaz.bindonce', 'Controllers', 'Directives', 'Factories', 'Filters', 'Services', 'ngSanitize']);


    ////////////////////////////////////////////////////////////
    // CONFIG
    ////////////////////////////////////////////////////////////

    App.config(['$routeProvider', '$provide', function ($routeProvider, $provide) {
        
		/*
		 * DataResolve is a function that ends up returning a promise.
		 * This function is then passed to every route that needs it.
	     * Views won't be loaded until the promise is resolved, allowing to initialize data with a request.
		*/

        //var dataResolve = function(Helper, $route) {
           // return Helper.helperMethod(param1, param2);  // "Helper" is a service with a method that returns a promise which loads some data when resolved.
        //}

        // $routeProvider.when('/', {
        //     templateUrl: 'pages/home.html',
        //     controller: 'HomeController',
        //     resolve: {teams: dataResolve}
        // });
		
        // $routeProvider.when('/OtherPage/:id', {
        //     templateUrl: 'pages/other.html',
        //     controller: 'OtherController'
        // });
        $routeProvider
            .when('/home', {
                templateUrl: 'pages/home.html',
                controller: 'ContactController'
            })
            .when('/home/contact/create', {
                templateUrl: 'pages/contact_form.html',
                controller: 'ContactController'
            })
            .when('/home/contact/edit/{id}', {
                templateUrl: 'pages/contact_form.html',
                controller: 'ContactController'
            })
            .otherwise('/home');

    }]);
})();
