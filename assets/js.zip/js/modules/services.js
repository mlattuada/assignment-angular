angular.module('Services', []);

// Add every service you create to this file.

require('./services/helper.js');
