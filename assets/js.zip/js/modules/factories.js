angular.module('Factories', []);

// Add every factory you create to this file.

require('./factories/someFactory.js');
