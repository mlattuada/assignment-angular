angular.module('Filters', []);

// Add every filter you create to this file

require('./filters/filters.js');
